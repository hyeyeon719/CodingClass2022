print (10%4)
print ((12+5)%8)