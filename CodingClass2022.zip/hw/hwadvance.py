a,b = map(int,input().split())
if(a%b == 0):
  print(str(a) + "은(는)" + str(b) + "(으)로 나누어 떨어진다")
else:
  print(str(a) + "은(는)" + str(b) + "(으)로 나누어 떨어지지 않는다")
